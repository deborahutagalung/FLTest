#!/usr/bin/env bash

while getopts t:c:a: flag
do
    case "${flag}" in
        t) ttype=${OPTARG};;
        c) ci=${OPTARG};;
        a) appid=${OPTARG};;
    esac
done

echo "INIT: Run on CI configuration is set to: ${ci}"

function runTest() {
  echo "START: Running all tests in ** $1 ** scope"
  ./mvnw test -B -e -q -Dci=$ci -Dkarate.env=$TEST_ENV -Dtest=$1 -Dcloud=true -Dapp=$ttype -Dappid=$appid

  if [[ $? -ne 0 ]] ; then
    if [[ $1 == "FeAppTestRunner" && $ttype == "all" ]] ; then
      echo "FINISH: There are test failures, continue for next test scope..."
    else
      echo "FINISH: There are test failures!"
      echo "Exiting with code 1."
      exit 1
    fi
  else
    if [[ $1 == "FeAppTestRunner" && $ttype == "all" ]] ; then
      echo "CONTINUE: Next test scope..."
    else
      echo "FINISH: Test execution done!"
      echo "Exiting with code 0"
      exit 0
    fi
  fi
}

if [[ $ttype == "fe-app" ]]
then
  runTest "FeAppTestRunner"
elif [[ $ttype == "transporter-app" ]]
then
  runTest "TransporterAppTestRunner"
elif [[ $ttype == "all" ]]
then
  runTest "FeAppTestRunner"
  runTest "TransporterAppTestRunner"
else
  echo "Invalid test type: options [ FeAppTestRunner, TransporterAppTestRunner ]"
fi
