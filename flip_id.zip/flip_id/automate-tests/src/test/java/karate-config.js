function fn() {
    var config = {}

    var cloud = karate.properties['cloud']
    var app = karate.properties['app']
    var appId = karate.properties['appid']

    cloud = !cloud ? 'false' : cloud.toLowerCase();
    karate.log('karate.cloud system property was:', cloud);

    driverConfig = { type: 'android', showDriverLog: true}
    driverConfig.httpConfig = { readTimeout: 120000}

    if (cloud == 'true') {
        var caps = karate.callSingle('classpath:utils/capabilities/capabilities.feature@cloud_capabilities', { 'app': app })
        caps.jsonCaps.desiredCapabilities.app = appId;

        driverConfig.webDriverUrl = 'http://hub-cloud.browserstack.com/wd/hub'
    } else {
        var caps = karate.callSingle('classpath:utils/capabilities/capabilities.feature@local_capabilities', { 'app': app })
        driverConfig.webDriverPath = '/wd/hub'
    }

    config.mobileDriver = {
        webDriverSession: caps.jsonCaps
    }

    config.gqlUrl = 'https://flip.id';
    config.restUrl = 'https://flip.id';
    karate.configure('driver', driverConfig);

    return config;
}
