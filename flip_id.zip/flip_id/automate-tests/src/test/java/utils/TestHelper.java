package utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class TestHelper {
    /***
     * Testing purpose
     */

    public static String generateRandomString(String prefix, String suffix, int length) {
        return generateRandomString(false, prefix, suffix, length);
    }

    public static String generateRandomInteger(String prefix, String suffix, int length) {
        return generateRandomString(true, prefix, suffix, length);
    }

    public static String generateRandomString(boolean numericOnly, String prefix, String suffix, int length) {
        String text = "";
        String possible = numericOnly ? "123456789" : "abcdefghijklmnopqrstuvwxyz123456789";

        for (int i = 0; i < length; i++) {
            text += possible.charAt((int) (Math.random() * possible.length()));
        }
        return prefix + text + suffix;
    }

    public static String generateCurrentTimeWithZone(int hourOffset, String pattern) {
        Date date = new Date();
        date = new Date(System.currentTimeMillis() + (hourOffset * 3600000));
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        return formatter.format(date);
    }
}
