import json
import argparse
import datetime
import requests
from tabulate import tabulate
from contextlib import ExitStack

"""
    Sample usage:
    `python parse_karate_summary.py get-percentage-success -f folder1/karate-summary-json.txt folder2/karate-summary-json.txt`
    `python parse_karate_summary.py get-duration -f folder1/karate-summary-json.txt folder2/karate-summary-json.txt`
"""
class KarateSummaryParser:
    def main(self, command_line=None):
        parser = argparse.ArgumentParser('Parse karate summary report')
        subparsers = parser.add_subparsers(dest='command')

        parser_get_duration = subparsers.add_parser('get-duration', help='Get duration of test run')
        parser_get_duration.add_argument('-f', required=True, nargs='+', help='File path to karate summary')

        parser_get_avg_success = subparsers.add_parser('get-percentage-success', help='Get success percentage of test run')
        parser_get_avg_success.add_argument('-f', required=True, nargs='+', help='File path to karate summary')

        parser_notify_slack = subparsers.add_parser('notify-to-slack', help='Notify result to slack channel with defined hook')
        parser_notify_slack.add_argument('-f', required=True, nargs='+', help='File path to karate summary')
        parser_notify_slack.add_argument('-w', required=True, help='Slack Webhook')
        parser_notify_slack.add_argument('-n', required=True, help='Build name')
        parser_notify_slack.add_argument('-e', required=True, help='Test env')
        parser_notify_slack.add_argument('-d', required=True, help='Test description')
        parser_notify_slack.add_argument('-u', required=True, help='Build url')
        parser_notify_slack.add_argument('-t', required=False, help='Testrail url')
        parser_notify_slack.add_argument('-r', required=False, help='Total duration')

        parser_slack_msg = subparsers.add_parser('get-slack-msg', help='Generate slack message from a Karate summary file')
        parser_slack_msg.add_argument('-f', required=True, nargs='+', help='File path to karate summary')

        args = parser.parse_args(command_line)
        if args.command == 'get-duration':
            self.get_duration(args.f)
        elif args.command == 'get-percentage-success':
            self.get_percentage_success(args.f)
        elif args.command == 'get-slack-msg':
            self.get_slack_rich_message(args.f)
        elif args.command == 'notify-to-slack':
            self.send_slack_message(args)

    def get_duration(self, args):
        total_time = 0
        with ExitStack() as stack:
            files = [
                stack.enter_context(open(filename))
                for filename in args
            ]
            for i, file in enumerate(files):
                data = json.load(file)
                total_time+= data['totalTime']
        print(total_time)

    def get_percentage_success(self, args):
        scenario_passed = 0
        scenario_failed = 0

        with ExitStack() as stack:
            files = [
                stack.enter_context(open(filename))
                for filename in args
            ]
            for i, file in enumerate(files):
                data = json.load(file)
                scenario_passed += data['scenariosPassed']
                scenario_failed += data['scenariosfailed']
        avg_percentage_success = scenario_passed / (scenario_passed + scenario_failed) * 100
        print(avg_percentage_success)

    def get_slack_rich_message(self, args):
        tbl_summary = ""
        with ExitStack() as stack:
            files = [
                stack.enter_context(open(filename))
                for filename in args
            ]
            for i, file in enumerate(files):
                data = json.load(file)
                tbl, _ = self.build_table(data['featureSummary'])
                tbl_summary += tbl
                if i != len(files) -1: tbl_summary += "\n\n"
        print(tbl_summary)

    def build_table(self, data):
        scenario_total = 0
        passed_total = 0
        duration_total = 0
        table = []
        headers = ['feature-file', 'scenario-count', 'passed-count', 'failed-count', 'success %', 'duration']
        table.append(headers)
        for d in data:
            scenario_total += d['scenarioCount']
            passed_total += d['passedCount']
            duration_total += d['durationMillis']
            r = [
                    d['relativePath'], d['scenarioCount'],d['passedCount'],
                    d['scenarioCount'] - d['passedCount'],
                    '{:.1%}'.format(d['passedCount'] / d['scenarioCount']),
                    '{}'.format(datetime.timedelta(milliseconds=d['durationMillis']))
                ]
            table.append(r)
        #total, #scenario, #passed, #failed, #success, #duration
        r = [ "Total", scenario_total, passed_total, (scenario_total - passed_total), ('{:.1%}'.format(passed_total / scenario_total)),
              '{}'.format(datetime.timedelta(milliseconds=duration_total)) ]
        table.append(r)

        return tabulate(table, headers="firstrow", tablefmt="grid"), passed_total / scenario_total

    def send_slack_message(self, args):
        webhook = args.w
        tbl_summary = ""
        total_pass_percentage = 0

        with ExitStack() as stack:
            files = [
                stack.enter_context(open(filename))
                for filename in args.f
            ]
            for i, file in enumerate(files):
                data = json.load(file)
                tbl, pass_percentage = self.build_table(data['featureSummary'])
                tbl_summary += tbl
                if i != len(files) -1: tbl_summary += "\n\n"
                total_pass_percentage += pass_percentage

        total_pass_percentage =  ('{:.1%}'.format(total_pass_percentage / len(args.f)))
        pre_message = self.build_pre_message(args, str(total_pass_percentage))
        req = requests.post(webhook, json=pre_message)
        print("Sending pre-message: " + req.text)

        body_message = self.build_body_message(args.n, tbl_summary)
        req = requests.post(webhook, json=body_message)
        print("Sending body-message: " + req.text)

    def build_body_message(self, name, table_body):
        msg = {
            "text": "Automation result for " + name,
            "blocks": [
                {
                    "type": "rich_text",
                    "elements": [
                        {
                            "type": "rich_text_preformatted",
                            "elements": [
                                {
                                    "type": "text",
                                    "text" : table_body
                                }
                            ]
                        }
                    ]
                }
            ]
        }
        return msg

    def build_pre_message(self, args, pass_percentage):
        msg = {
            "text": "Automation result for " + args.n,
            "blocks": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": ":information_source:\t\t" + args.n
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": "*Environment:*\n" + args.e
                        },
                        {
                            "type": "mrkdwn",
                            "text": "*Desc:*\n " + args.d
                        },
                        {
                            "type": "mrkdwn",
                            "text": "*Total time to complete test:*\n" + args.r
                        },
                        {
                            "type": "mrkdwn",
                            "text": "*Total pass percentage:*\n" + pass_percentage
                        }
                    ]
                },
                {
                    "type": "section",
                    "fields": [
                        {
                            "type": "mrkdwn",
                            "text": "<" + args.u + "|View Jenkins Build>"
                        },
                        {
                            "type": "mrkdwn",
                            "text": "<" + args.t + "|View TestRail Run>"
                        }
                    ]
                }
            ]
        }
        return msg


if __name__ == '__main__':
    k = KarateSummaryParser()
    k.main()